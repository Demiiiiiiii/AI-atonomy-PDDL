# Student Information

**Course:** COMP90054 AI Planning for Autonomy

**Semester:** Semester 2, 2022

**Student:**

* 1249398 - Jiayun - Huang - jiayunh3@student.unimelb.edu.au*


